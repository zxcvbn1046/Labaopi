﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABA1
{
    public class super_slave
    {
        public string name;
        public string group;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        

        public string Group
        {
            get { return group; }
            set { group = value; }
        }
    }
}
